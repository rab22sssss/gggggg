import assert from 'node:assert/strict';
import worker from './Bluesky_Ultra_Autopilot.js';
class MockKV {
  constructor(seed={}) { this.data = new Map(Object.entries(seed)); }
  async get(k) { return this.data.has(k) ? this.data.get(k) : null; }
  async put(k,v) { this.data.set(k,String(v)); }
  async delete(k) { this.data.delete(k); }
}
const kv = new MockKV({
  discovery_seen_v1: JSON.stringify([
    {uri:'at://seen-old',seenAt:Date.now()-40*86400000},
    {uri:'at://seen-new',seenAt:Date.now()-1000}
  ]),
  discovery_analysis_v1: JSON.stringify([
    {uri:'at://analysis-old',reviewedAt:Date.now()-40*86400000},
    {uri:'at://analysis-new',reviewedAt:Date.now()-1000}
  ])
});
const env = { ADMIN_KEY:'test-secret', BSKY_DB:kv };
async function request(path, {method='GET', body, auth=true}={}) {
  const headers = new Headers();
  if (auth) headers.set('Authorization','Bearer test-secret');
  if (body !== undefined) headers.set('Content-Type','application/json');
  return worker.fetch(new Request('https://worker.test'+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)}),env,{});
}
// Auth is enforced when a key is configured.
assert.equal((await request('/api/discovery/history',{auth:false})).status,401);
// History is recent-only, capped, newest first, and reports KV persistence.
let r = await request('/api/discovery/history?limit=1');
assert.equal(r.status,200);
let j = await r.json();
assert.equal(j.persisted,true); assert.equal(j.seen.length,1); assert.equal(j.analyzed.length,1);
assert.equal(j.seen[0].uri,'at://seen-new'); assert.equal(j.analyzed[0].uri,'at://analysis-new');
// Analysis ignores null/array entries, clamps invalid counts, and persists only valid candidates.
r = await request('/api/discovery/analyze',{method:'POST',body:{query:'gardening plants',posts:[null,[],{uri:'at://good',text:'Gardening plants are useful for a small home garden.',metrics:{likeCount:'Infinity',repostCount:-9,replyCount:3}},{uri:'at://other',text:'hello'}]}});
assert.equal(r.status,200); j=await r.json(); assert.equal(j.count,2); assert.equal(j.mode,'heuristic_not_ai');
const good=j.results.find(x=>x.uri==='at://good'); assert.ok(good); assert.equal(good.metrics.likeCount,0); assert.equal(good.metrics.repostCount,0);
assert.ok(JSON.parse(await kv.get('discovery_analysis_v1')).some(x=>x.uri==='at://good'));
// Empty/invalid posts fail clearly.
r = await request('/api/discovery/analyze',{method:'POST',body:{query:'x',posts:[null,[]]}}); assert.equal(r.status,400);
// No KV is explicit and does not pretend persistence exists.
const noKvEnv={ADMIN_KEY:'test-secret'};
r = await worker.fetch(new Request('https://worker.test/api/discovery/history',{headers:{Authorization:'Bearer test-secret'}}),noKvEnv,{});
assert.equal(r.status,200); j=await r.json(); assert.equal(j.persisted,false);
console.log('PASS: auth, history retention/limit/order, malformed analysis inputs, metric clamping, KV persistence, no-KV response');
