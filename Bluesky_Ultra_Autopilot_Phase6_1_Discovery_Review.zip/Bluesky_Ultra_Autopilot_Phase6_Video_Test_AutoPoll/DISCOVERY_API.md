# Discovery API — Phases 1 and 2

All endpoints use the Worker’s existing admin authorization.

## Search public posts
`GET /api/discovery/search?q=photography&limit=20`
Returns public post text, author profile summary, engagement counts, and a bounded `alreadySeen` marker where KV is available.

## Get public profile
`GET /api/discovery/profile?actor=bsky.app`
Returns public profile details.

## Analyze candidates
`POST /api/discovery/analyze`
JSON body:
```json
{
  "query": "street photography",
  "posts": [
    {"uri":"at://...","text":"A street photography walk","author":{"handle":"example.bsky.social","displayName":"Example","followersCount":120},"metrics":{"likeCount":5,"repostCount":1,"replyCount":2},"alreadySeen":false}
  ]
}
```
Up to 50 posts. Returns a `relevanceScore` (0–100), matched terms, reasons, and a review recommendation. The score is a transparent lexical heuristic, **not an AI semantic judgment** and not a measure of user intent or account trustworthiness. Treat it as a triage aid and manually review before interaction. No engagement actions are performed.

KV keys:
- `discovery_seen_v1`: deduplication markers from search.
- `discovery_analysis_v1`: bounded analysis history (up to 2,000 entries, 30 days).

## Deployment cautions
- Bind KV as `BSKY_DB` (or a binding recognized by the existing Worker).
- Configure `ADMIN_PASSWORD` or `ADMIN_KEY`; legacy auth permits access if no key is configured.
- These routes still require a live Cloudflare test; syntax/unit checks do not prove external API availability.
