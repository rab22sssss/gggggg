# Cron and scheduled-publishing review — Phase 5 baseline

## Changes made
- Wrapped the scheduled Worker task with a rejection handler and attempted to record fatal Cron errors in `post_logs` using `kind: cron-fatal`.
- Added a retry delay and failure log to unexpected exceptions in the image, text, and video posting branches. The delay uses each media type's configured interval, clamped to 1–120 minutes.
- Kept existing post-success queue consumption and interval logic intact. No changes were made to video preview code, dashboard layout, account storage schema, or KV binding discovery.

## Important deployment distinction
The Worker source contains the `scheduled()` entry point, but the ZIP does not include Cloudflare's dashboard Cron Trigger configuration or a GitHub Actions workflow. Therefore this package cannot verify which Cron expression is configured in your Cloudflare account, whether a GitHub Action is scheduled, or whether both schedulers might invoke the Worker. Those settings must be inspected in the relevant platform UI/repository.

## Verification performed
- JavaScript syntax check.
- Static assertions that Cron error handling, image/text/video retry delays, and error logs are present.
- ZIP integrity check.

## Not verified
- Live Cloudflare Cron execution, live KV writes, live Bluesky publishing, concurrent overlapping Cron invocations, or GitHub Actions scheduling.
- Exactly-once publishing cannot be guaranteed by these changes: a remote post could succeed before a subsequent KV persistence failure.


## Dashboard diagnostics addition
- Added client-side filters for account, media/system type, success/failure, and free-text search across the existing recent log entries.
- Added a visible Cron-failure summary based only on errors actually present in the saved log. The UI explicitly warns that an empty error list does not prove the external Cron Trigger is running.
- Kept filters local to the dashboard; they do not change posting behavior, schedules, queues, credentials, or KV bindings.
- Browser dashboard inline JavaScript was extracted and passed `node --check`; existing Phase 3/4 test scripts passed. No browser automation or live Cloudflare test was run.
