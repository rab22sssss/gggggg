# Change log — Phase 5 Stabilized

- Based on the previously corrected Phase 4 build; original Worker source included byte-for-byte as a recovery reference.
- Fixed the GET-authentication retry to explicitly send the accepted admin key on the retry request.
- Removed a duplicated `endAmPm` select with a duplicate DOM id in the image schedule UI.
- Refined discovery panel spacing and bounded result/history areas for easier navigation on desktop and mobile.
- No KV binding names, stored account data, scheduled logic, posting endpoints, or secrets were changed intentionally.
- Strict random/progressive isolation remains deferred to the final phase as requested.


## Cron / scheduled-posting hardening (Phase 5 baseline)

- Cron-level failures are caught and recorded as a system log entry instead of becoming an unhandled scheduled-task rejection.
- Unexpected exceptions in image/text/video publishing now set a bounded retry delay and record a failure log, reducing repeated immediate retries when a Cron runs frequently.
- Existing publishing logic, queues, preview handling, account/KV schema, and dashboard markup were otherwise left unchanged.
- Random/progressive strict isolation remains intentionally deferred to the final phase.


## Phase 6.1 — Discovery review controls
- Added client-side filtering of discovered posts by text, handle, or display name.
- Added optional sorting by heuristic relevance score or public engagement counts.
- Kept the original search order as the default; controls do not open tabs or profiles automatically.
- No changes to video queue cleanup, publishing endpoints, account login, KV schema, Cron, or secrets.
