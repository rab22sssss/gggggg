# Phase 6 — Video Test Auto-Poll

## Base
Created as a separate copy of `Bluesky_Ultra_Autopilot_Phase5_Log_Diagnostics_2_Verified`. The Phase 5 source package is not modified.

## Changes
- The **Test Video** button now automatically re-checks a Bluesky video processing job every 5 seconds, for up to 18 checks (about 90 seconds), instead of requiring the user to click it again after processing begins.
- Re-checks reuse the saved `jobId` on the same first queue item; the UI does not intentionally initiate a fresh upload while a known job is processing.
- If a processing job reaches a terminal error, the stale `jobId` is cleared and the error is saved so a later manual retry can start cleanly.
- If processing still continues after about 90 seconds, the UI says so and stops polling; the user may click again later to re-check the same saved job.
- No changes to account login, KV binding discovery, credentials, scheduled posting, Cron configuration, image/text publishing, or dashboard tab logic.

## Local verification
- JavaScript syntax check.
- Existing Phase 3 and Phase 4 tests.
- ZIP integrity check.
- Static checks for the auto-poll loop and stale-job cleanup.

## Limitations
No live Cloudflare deployment or Bluesky post was executed. A successful local test cannot prove the external video service's processing duration or live deployment behavior. Keep Phase 5 as the rollback version until the new button is tested in a separate deployment.
- After a successful test-video publish, the exact tested queue item is removed from that account's `videoQueue` and the account state is saved, so the side preview no longer shows the completed test item as processing. Other queue items remain untouched.
